package com.leaftaps.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReadProperty {
public static void main(String[] args) throws IOException {
	Properties prop = new Properties();
	FileInputStream file = new FileInputStream("./configuration/RunConfig.properties");
	prop.load(file);
	System.out.println(prop.getProperty("url"));
	System.out.println(prop.getProperty("browser"));
}
}

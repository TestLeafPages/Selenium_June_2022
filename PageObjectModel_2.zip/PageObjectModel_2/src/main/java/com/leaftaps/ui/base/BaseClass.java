package com.leaftaps.ui.base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import com.leaftaps.utils.ReadExcelData;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {
	public RemoteWebDriver driver;
	public String excelFileName;
	public static Properties property;
	@BeforeMethod
	public void beforeMethod() throws IOException {
		// Get the run configurations
		Properties prop = new Properties();
		FileInputStream file = new FileInputStream("./configuration/RunConfig.properties");
		prop.load(file);
		String browserName = prop.getProperty("browser");
		
		if (browserName.equals("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		} else {
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
		}
		driver.get(prop.getProperty("url"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		String lang = prop.getProperty("lang");
		property = new Properties();
		FileInputStream file1 = new FileInputStream("./configuration/"+lang+".properties");
		property.load(file1);
	}

	@AfterMethod
	public void afterMethod() {
		driver.quit();
	}
	
	@DataProvider
	public String[][] testData() throws IOException {
	return ReadExcelData.getData(excelFileName);
	}
}

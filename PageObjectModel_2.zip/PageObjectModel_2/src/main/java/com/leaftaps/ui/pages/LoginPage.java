package com.leaftaps.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.leaftaps.ui.base.BaseClass;

public class LoginPage extends BaseClass {

	public LoginPage(RemoteWebDriver driverValue) {
		this.driver = driverValue;
	}

	public LoginPage enterUsername(String username) {
		WebElement usernameElement = driver.findElement(By.id(property.getProperty("loginpage.username")));
		usernameElement.sendKeys(username);
//		LoginPage obj = new LoginPage();
//		return obj;
		return this;
	}

	public LoginPage enterPassword(String password) {
		WebElement passwordElement = driver.findElement(By.name(property.getProperty("loginpage.password")));
		passwordElement.sendKeys(password);
		return this;
	}

	public WelcomePage clickLogin() {
		WebElement loginButton = driver.findElement(By.className(property.getProperty("loginpage.login")));
		loginButton.click();
		return new WelcomePage(driver);
	}
}

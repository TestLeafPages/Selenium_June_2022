package com.leaftaps.ui.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.leaftaps.ui.base.BaseClass;

public class ViewLeadPage extends BaseClass {

	public ViewLeadPage(RemoteWebDriver driverValue) {
		this.driver = driverValue;
	}
	public ViewLeadPage verifyLead() {
		System.out.println("Lead Created");
		return this;
	}
}

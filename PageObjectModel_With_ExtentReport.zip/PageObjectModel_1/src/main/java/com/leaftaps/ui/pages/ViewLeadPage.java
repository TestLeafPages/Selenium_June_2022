package com.leaftaps.ui.pages;

import com.leaftaps.ui.base.BaseClass;

public class ViewLeadPage extends BaseClass {

	public ViewLeadPage() {

	}
	public ViewLeadPage verifyLead() {
		System.out.println("Lead Created");
		return this;
	}
}

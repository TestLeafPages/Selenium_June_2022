package com.leaftaps.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.leaftaps.ui.base.BaseClass;

public class LoginPage extends BaseClass {

	public LoginPage() {

	}

	public LoginPage enterUsername(String username) {
		WebElement usernameElement = driver.findElement(By.id("username"));
		usernameElement.sendKeys(username);
//		LoginPage obj = new LoginPage();
//		return obj;
		return this;
	}

	public LoginPage enterPassword(String password) {
		WebElement passwordElement = driver.findElement(By.name("PASSWORD"));
		passwordElement.sendKeys(password);
		return this;
	}

	public WelcomePage clickLogin() {
		WebElement loginButton = driver.findElement(By.className("decorativeSubmit"));
		loginButton.click();
		return new WelcomePage();
	}
}
